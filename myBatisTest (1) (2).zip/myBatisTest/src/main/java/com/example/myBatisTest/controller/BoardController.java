package com.example.myBatisTest.controller;

import com.example.myBatisTest.dto.BoardDto;
import com.example.myBatisTest.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class BoardController {
    @Autowired
    BoardService boardService;

    @GetMapping("/")
//    @RequestMapping(value = {"/" ,""}, method = RequestMethod.GET)
    public String inxdex(){
        return "/index";
    }

    @GetMapping("/save")
    public String save(){
        return "/save";
    }

    @PostMapping("/save")
    public String saveBoard(BoardDto boardDto){
        boardService.save(boardDto);
        return "redirect:/list";
    }

    @GetMapping("/list")
    public String findAll(Model model){
        List<BoardDto> boardDtoList = boardService.findAll();
        model.addAttribute("boardList" , boardDtoList);
        return "list";
    }

    @GetMapping("/board/{id}")
    public String findOne(@PathVariable("id") Long id , Model model ){
        BoardDto boardDto = boardService.findById(id);
        boardService.addBoardHits(id);
        model.addAttribute("boardDto" , boardDto);
        return "board";
    }

    @PostMapping("/update")
    public String updateForm(BoardDto boardDto){
        boardService.update(boardDto);
        return "redirect:/list";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") Long id){
        boardService.delete(id);
        return "redirect:/list";
    }

}
