package com.example.myBatisTest.mapper;

import com.example.myBatisTest.dto.BoardDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface BoardMapper {
    Long save(@Param("boardDto")BoardDto boardDto);

    List<BoardDto> findAll();

    BoardDto findById(@Param("id")Long id);

    void addBoardHit(@Param("id")Long id);

    void update(@Param("boardDto") BoardDto boardDto);

    void delete(@Param("id") Long id);
}
