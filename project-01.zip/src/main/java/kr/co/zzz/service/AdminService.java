package kr.co.zzz.service;

import java.util.HashSet;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import kr.co.zzz.dto.AdminDto;
import kr.co.zzz.dto.AdminUpdateDto;
import kr.co.zzz.mapper.AdminMapper;

@Service
public class AdminService {

	@Autowired
	AdminMapper adminMapper;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	public int adminInsert(AdminDto adminDto) {
		adminDto.setA_pw(passwordEncoder.encode(adminDto.getA_pw()));
		
		if(adminDto.getA_id().equals("admin")) {
			adminDto.setA_approval(1);
		}
		
		return adminMapper.adminInsert(adminDto);
	}

	public AdminDto loginConfirm(AdminDto adminDto) {
		AdminDto dto = new AdminDto();
		dto = adminMapper.loginConfirm(adminDto);
		return dto;
	}

	public List<AdminDto> adminList() {
		
		return adminMapper.adminList();
	}

	public void setAdminApproval(String id) {
		adminMapper.setAdminApproval(id);	
	}

	public void modifyAccount(AdminUpdateDto adminUpdateDto) {
		adminMapper.modifyAccount(adminUpdateDto);
	}
	
	public AdminDto getById(String Id) {
		return adminMapper.getById(Id);
	}

	public List<AdminDto> searchAdminConfirm(String category, String keyword) {
		
		return adminMapper.searchAdminConfirm(category, keyword);
	}

}
