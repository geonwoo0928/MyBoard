package kr.co.zzz.mapper;

import java.util.HashSet;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import kr.co.zzz.dto.AdminDto;
import kr.co.zzz.dto.AdminUpdateDto;

@Mapper
public interface AdminMapper {

	int adminInsert(@Param("adminDto") AdminDto adminDto);

	AdminDto loginConfirm(@Param("adminDto") AdminDto adminDto);

	List<AdminDto> adminList();

	void setAdminApproval(String id);

	void modifyAccount(AdminUpdateDto adminUpdateDto);

	AdminDto getById(String id);

	List<AdminDto> searchAdminConfirm(@Param("category")String category , 
			@Param("keyword")String keyword);
	
}
