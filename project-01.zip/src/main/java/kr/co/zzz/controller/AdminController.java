package kr.co.zzz.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.co.zzz.dto.AdminDto;
import kr.co.zzz.dto.AdminUpdateDto;
import kr.co.zzz.service.AdminService;

@Controller 
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	AdminService adminService;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@GetMapping("")
	public String mainView() {
		return "/admin/main";
	}
	
	@GetMapping("/handlerInterceptor")
	public String handlerInterceptor() {
		return "/admin/handler-interceptor";
	}

	
	@GetMapping("/createAccountForm")
	public String createAccountForm() {
		
		return "/admin/create_account_form";
	}
	
	@PostMapping("/createAccountConfirm")
	public String createAccountConfirm(AdminDto adminDto) {
		System.out.println(adminDto.toString());
		int i = adminService.adminInsert(adminDto);
		return "/admin/create_account_form";
	}
	
	@GetMapping("/loginForm")
	public String loginForm() {
		
		return "/admin/login_form";
	}
	
	@PostMapping("/loginConfirm") //HttpSession 은 Model과 동일이지만 유효기간이 있는 Model 세션 만료
	public String loginConfirm(AdminDto adminDto , HttpSession session) {
		String page = "/admin/login_ok";
		
		AdminDto adminLoginedDto = adminService.loginConfirm(adminDto);
		
		if(adminLoginedDto == null) {
			page= "/admin/login_ng";
			return page;
		}
		
		if(passwordEncoder.matches(adminDto.getA_pw(), adminLoginedDto.getA_pw())) {
			session.setAttribute("adminLoginedDto", adminLoginedDto);
			session.setMaxInactiveInterval(60*30); // 60초 * 30 = 30분
			return page;
		}else {
			page = "/admin/login_ng";
			return page;
		}
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/admin";
	}
	
	@GetMapping("/listupAdmin")
	public String listupAdmin(Model model) {
		String page = "/admin/admin_list";
		
		List<AdminDto> adminDtos = adminService.adminList();
		
		model.addAttribute("adminDtos" , adminDtos);
		
		return page;
	}
	
	@GetMapping("/setAdminApproval")
	public String setAdminApproval(@RequestParam("id") String id) {
		adminService.setAdminApproval(id);
		
		return "redirect:/admin/listupAdmin";
	}
	
	@GetMapping("/modifyAccountForm")
	public String modifyAccountForm(Model model , HttpSession session) {
		String page = "/admin/modify_account_form";
		AdminDto adminLoginedDto = (AdminDto) session.getAttribute("adminLoginedDto");
		//세션
		if(adminLoginedDto != null) {
			model.addAttribute("adminLoginedDto" , adminLoginedDto);
			return page;
		}else {
			//세션만료
			page = "redirect:/admin/loginForm";
			return page;
		}
	}
	
	@PostMapping("/modifyAccountConfirm")
	public String modifyAccountConfirm(AdminDto adminDto , HttpSession session) {
		String page = "redirect:/admin/listupAdmin";
		AdminDto beforeAdminDto = (AdminDto) session.getAttribute("adminLoginedDto");
		String id = beforeAdminDto.getA_id();
		AdminDto afterAdminDto = new AdminDto();
		
		AdminUpdateDto adminUpdateDto = new AdminUpdateDto(adminDto , id);
		
		//수정 후 관리자 리스트 페이지로 이동
		if(adminDto != null) {
			adminService.modifyAccount(adminUpdateDto);
			afterAdminDto = adminService.getById(beforeAdminDto.getA_id());
			session.setAttribute("adminLoginedDto", afterAdminDto);
			session.setMaxInactiveInterval(60*30);
		}else {
			page = "redirect:/admin/modifyAccountForm";
			return page;
		}
		
		return page;
	}
	
	
	@GetMapping("/searchAdminConfirm")
	public String searchAdminConfirm(@RequestParam("category")String category ,
			@RequestParam("keyword") String keyword , Model model) {
		List<AdminDto> adminDtos = new ArrayList<AdminDto>();
		if(category.equals("None") && keyword == null) {
			adminDtos = adminService.adminList();
			model.addAttribute("adminDtos", adminDtos);
		}else {
			adminDtos = adminService.searchAdminConfirm(category,keyword);
			model.addAttribute("adminDtos", adminDtos);
		}
		
		return "/admin/admin_list";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
