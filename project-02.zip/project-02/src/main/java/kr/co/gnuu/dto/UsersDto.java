package kr.co.gnuu.dto;

public class UsersDto {

}
