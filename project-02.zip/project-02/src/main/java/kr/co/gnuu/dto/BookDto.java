package kr.co.gnuu.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookDto {

	private String b_name;
	private String b_author;
	private String b_publisher;
	private String b_isbn;
}
