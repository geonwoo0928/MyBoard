package kr.co.gnuu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.gnuu.dto.BookDto;
import kr.co.gnuu.mapper.BookMapper;

@Service
public class BookService {

	@Autowired
	BookMapper bookMapper;
	
	public void insertBook(BookDto bookDto) {
		bookMapper.insertBook(bookDto);
	}

}
