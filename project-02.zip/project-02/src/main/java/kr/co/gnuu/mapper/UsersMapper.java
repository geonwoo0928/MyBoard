package kr.co.gnuu.mapper;

public interface UsersMapper {

}
