package kr.co.gnuu.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import kr.co.gnuu.dto.BookDto;
@Mapper
public interface BookMapper {

	void insertBook(@Param("bookDto")BookDto bookDto);

}
