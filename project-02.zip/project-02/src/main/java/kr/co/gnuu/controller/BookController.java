package kr.co.gnuu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import kr.co.gnuu.dto.BookDto;
import kr.co.gnuu.service.BookService;

@Controller
public class BookController {
	@Autowired
	BookService bookservice;

	@GetMapping("/insert")
	public String insertBook() {
		
		return "/book/insert-book";
	}
	
	@PostMapping("/insert-book")
	public String insertBookForm(BookDto bookDto) {
		System.out.println(bookDto.toString());
		bookservice.insertBook(bookDto);
		return "redirect:/";
	}
}
