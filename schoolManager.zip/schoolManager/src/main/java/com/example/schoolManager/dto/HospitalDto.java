package com.example.schoolManager.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HospitalDto {
    private String hostCode;
    private String hostName;
    private String hostTel;
    private String hostAddr;
}
