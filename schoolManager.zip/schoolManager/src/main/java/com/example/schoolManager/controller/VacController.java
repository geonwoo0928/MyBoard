package com.example.schoolManager.controller;

import com.example.schoolManager.dto.CurrentResvDto;
import com.example.schoolManager.dto.HospitalDto;
import com.example.schoolManager.dto.ResvResultDto;
import com.example.schoolManager.dto.VaccresvDto;
import com.example.schoolManager.service.VaccineService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class VacController {
    @Autowired
    VaccineService vaccineService;

    @GetMapping("/")
    public String main(){
        return "html/home";
    }//메인페이지

    @GetMapping("/vaccine/reservation")
    public String vaccine(Model model){
        //예약코드 출력
        int reservationCode = vaccineService.makeReservationCode() + 1;
        VaccresvDto vaccresvDto = new VaccresvDto();

        model.addAttribute("vaccresvDto" , vaccresvDto);
        model.addAttribute("reservationCode",reservationCode);
        return "html/reservation";
    }//백신예약페이지

    @PostMapping("/vaccine/reservation")
    public String vaccineResv(@Valid @ModelAttribute("vaccresvDto") VaccresvDto vaccresvDto ,
                              BindingResult bindingResult , Model model){
        if(bindingResult.hasErrors()){
            int reservationCode = vaccineService.makeReservationCode() + 1;
            List<HospitalDto> hostList = vaccineService.getHost();
            model.addAttribute("reservationCode",reservationCode);
            model.addAttribute("hostList" , hostList);
            return "html/reservation";
        }

        vaccineService.saveReservation(vaccresvDto);
        return "redirect:/";
    } //백신예약

    @GetMapping("/vaccine/search")
    public String searchResv(){
        return "/html/search";
    }

    @GetMapping("/vaccine/search/result")
    public String searchResvResult(@ModelAttribute("resvNo") int resvNo , Model model){
        ResvResultDto resvResultDto = vaccineService.getResvById(resvNo);
        if(resvResultDto == null){
            model.addAttribute("resvNo" , resvNo);
            return "/html/searchNothing";
        }
        model.addAttribute("resvResultDto" , resvResultDto);
        return "/html/searchResult";
    }

    @GetMapping("/reservation/current")
    public String currentReservtion(Model model){
        List<CurrentResvDto> currentResvDtoList = vaccineService.searchCurrentResv();
        model.addAttribute("currentResvDtoList" , currentResvDtoList);
        return "/html/current";
    }
}