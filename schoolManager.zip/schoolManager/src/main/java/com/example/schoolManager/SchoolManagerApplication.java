package com.example.schoolManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolManagerApplication.class, args);
	}

}
