package com.example.schoolManager.service;

import com.example.schoolManager.dto.CurrentResvDto;
import com.example.schoolManager.dto.HospitalDto;
import com.example.schoolManager.dto.ResvResultDto;
import com.example.schoolManager.dto.VaccresvDto;
import com.example.schoolManager.mapper.VaccineMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class VaccineService {
    @Autowired
    VaccineMapper vaccineMapper;
    public int makeReservationCode() {
        return vaccineMapper.makeReservationCode();
    }

    public List<HospitalDto> getHost() {
        return vaccineMapper.getHost();
    }

    public List<String> getVCode() {
        return vaccineMapper.getVCode();
    }

    public void saveReservation(VaccresvDto vaccresvDto) {
        vaccineMapper.saveReservation(vaccresvDto);
    }

    public ResvResultDto getResvById(int resvNo) {
        return vaccineMapper.getResvById(resvNo);
    }

    public List<CurrentResvDto> searchCurrentResv() {
        List<CurrentResvDto> currentResvDtoList = new ArrayList<>();
        int i ;
        String hospital = "H00";
        for(i=1; i<5; i++){
            CurrentResvDto currentResvDto = vaccineMapper.searchCurrentResv(hospital+i);
            if(currentResvDto == null){
                CurrentResvDto currentResvDto1 = new CurrentResvDto(i+"0",0);
                currentResvDtoList.add(currentResvDto1);
            }else{
                currentResvDtoList.add(currentResvDto);
            }
        }
        return currentResvDtoList;
    }
}
