package com.example.schoolManager.mapper;

import com.example.schoolManager.dto.HospitalDto;
import com.example.schoolManager.dto.ResvResultDto;
import com.example.schoolManager.dto.VaccresvDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface VaccineMapper {
    int makeReservationCode();

    List<HospitalDto> getHost();

    List<String> getVCode();

    void saveReservation(@Param("vaccresvDto")VaccresvDto vaccresvDto);

    ResvResultDto getResvById(int resvNo);
}
