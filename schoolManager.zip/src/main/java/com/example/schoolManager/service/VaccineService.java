package com.example.schoolManager.service;

import com.example.schoolManager.dto.HospitalDto;
import com.example.schoolManager.dto.ResvResultDto;
import com.example.schoolManager.dto.VaccresvDto;
import com.example.schoolManager.mapper.VaccineMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VaccineService {
    @Autowired
    VaccineMapper vaccineMapper;
    public int makeReservationCode() {
        return vaccineMapper.makeReservationCode();
    }

    public List<HospitalDto> getHost() {
        return vaccineMapper.getHost();
    }

    public List<String> getVCode() {
        return vaccineMapper.getVCode();
    }

    public void saveReservation(VaccresvDto vaccresvDto) {
        vaccineMapper.saveReservation(vaccresvDto);
    }

    public ResvResultDto getResvById(int resvNo) {
        return vaccineMapper.getResvById(resvNo);
    }
}
