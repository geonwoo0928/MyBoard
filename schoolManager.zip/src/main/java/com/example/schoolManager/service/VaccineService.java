package com.example.schoolManager.service;

import com.example.schoolManager.mapper.VaccineMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VaccineService {
    @Autowired
    VaccineMapper vaccineMapper;
    public int makeReservationCode() {
        return vaccineMapper.makeReservationCode();
    }

    public List<String> getHostName() {
        return vaccineMapper.getHostName();
    }
}
