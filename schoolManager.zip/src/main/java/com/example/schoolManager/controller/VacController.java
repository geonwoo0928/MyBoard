package com.example.schoolManager.controller;

import com.example.schoolManager.service.VaccineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class VacController {
    @Autowired
    VaccineService vaccineService;

    @GetMapping("/")
    public String main(){
        return "html/home";
    }//메인페이지

    @GetMapping("/vaccine/reservation")
    public String vaccine(Model model){
        //예약코드 출력
        int reservationCode = vaccineService.makeReservationCode() + 1;
        //병원이름 출력
        List<String> hostNameList = vaccineService.getHostName();
        model.addAttribute("reservationCode",reservationCode);
        model.addAttribute("hostNameList" , hostNameList);
        return "html/reservation";
    }//백신예약페이지
}
