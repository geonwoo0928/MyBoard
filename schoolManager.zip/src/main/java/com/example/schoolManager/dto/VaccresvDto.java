package com.example.schoolManager.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VaccresvDto {
    private int resvNo;

    @NotEmpty(message = "주민번호는 필수 입니다.")
    private String jumin;

    private String hostCode;

    @NotEmpty(message = "예약날짜는 필수 입니다.")
    private String resvDate;

    @NotEmpty(message = "예약시간은 필수 입니다.")
    private String resvTime;

    private String vCode;
}
