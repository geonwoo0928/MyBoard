package com.example.schoolManager.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResvResultDto {
    private int resv_no;
    private String name;
    private String jumin;
    private String host_name;
    private String resv_date;
    private String resv_time;
    private String v_code;
    private String host_addr;
}
