package com.example.schoolManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
