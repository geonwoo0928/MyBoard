$(function(){
  $("#btn-menu").on({
    click : function(){
      // $(".div-menu").slideDown('slow');
      $(".div-menu").slideToggle('slow');
    }
  });
});