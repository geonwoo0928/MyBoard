// 버튼 클릭 시 페이지 전체가 노란색으로

$(function(){

  $("button.btn1").click(function(){
    $("body").css("background-color", "yellow");
  });

  $("button.btn2").click(function(){
    $("p .intro").css("background-color" , "pink");
  });

});
