$(document).ready(function(){
  // h1 태그를 클릭하면 사라지도록

  $("h1").click(function(){
    $(this).hide();
    
  })
});
