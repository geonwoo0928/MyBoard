$(function(){
  $("#btn_1").click(function(){
    $("li:first-child").css("color" , "red");
  });

  $("#btn_2").click(function(){
    $("a[href = 'www.daum.net']").css("background-color" , "pink");
  });

  $("#btn_3").click(function(){
    $("tr:odd").css("background-color" , "gold");
  });
});

// document.body ,, $("*") == $("body")
// <p> ,, $("p")
// <p id="aa"> ,, $("#aa")
// <p class="bb"> ,, $("p.bb")
// <a href="kjlj"> ,, $("a[href = or !=]")
// DOM(Document Object Model)