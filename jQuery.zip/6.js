$(function(){
  $("#rose").on({
    click : function(){ $(this).hide(1); }
  });
  $("#btn-show").on({
    click : function(){ $("#rose").show(1,
      function(){
        $("#rose").hide('slow');
      }
    ); }
  });
});