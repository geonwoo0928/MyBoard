$(function(){
  // $("#a").fadeIn();
  $("#btn-fade").on({
    click : function(){
      $("#a").fadeIn(1000),
      $("#b").fadeIn(1000 , function(){
        alert("두번째 상자");
      }),
      $("#c").fadeIn(1000);
    }
  });

  $("#btn-fadeToggle").on({
    click : function(){
      $("#a").fadeToggle();
    }
  });

  $("#btn-fadeTo").on({
    click : function(){
      $("#a").fadeTo(3000 , 0);
    }
  });
});