$(function(){
  // $("#btn_1").click(function(){
  //   $("#enter1").hide();
  // });
  // $("#btn_1").dblclick(function(){
  //   $("#enter1").show();
  // });
  $("#btn_1").on({
    click : function(){$("#first").hide()},
    dblclick : function(){$("#first").show()}
  });
  // $("p").mouseenter(function () { 
  //   $(this).css("background-color" , "green");
  // });
  // $("p").mouseleave(function () { 
  //   $(this).css("background-color" , "white");
  // });
  $("p").on({
    mouseenter : function(){$(this).css("background-color" , "green")},
    mouseleave : function(){$(this).css("background-color" , "white")}
  });
  $("p.mouse").mousedown(function () { 
    $(this).css("background-color" , "pink");
  });
  $("p.mouse").mouseup(function () { 
    $(this).css("background-color" , "red");
  });
  $(".outer").mouseover(function () { 
    console.log("Outer MouseOver Event ~~");
  });
  $(".outer").mouseenter(function () { 
    console.log("Outer MouseEnter Event ~~")
  });
  $(".inner").mouseover(function () { 
    console.log("Inner MouseOver Event ~~");
  });
  $(".inner").mouseenter(function () { 
    console.log("Inner MouseEnter Event ~~")
  });
});