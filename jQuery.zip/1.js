$(function(){
  $("h2").click(function(){
    $("h2").hide();
  });
});