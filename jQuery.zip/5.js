$(function(){
  $("input[type = 'password']").focus(function(){
    $(this).css("background-color" , "pink");
  });
  $("input[type = 'password']").blur(function (e) { 
    e.preventDefault();
    $(this).css("background-color" , "");
  });

  $("h1").on({
    click : function () {
      $(this).css("background-color" , "red");},
    mouseenter : function (){
      $(this).css("background-color" , "yellow");},
    mouseleave : function(){
      $(this).css("background-color" , "white");}
    });
});
