package com.example.jpaTest.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
public class Parent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long parentId;

    @OneToMany(mappedBy = "parent" , cascade = CascadeType.PERSIST,orphanRemoval = true) //부모에 연관있는 자식들도 저장됨
    private List<Child> childList = new ArrayList<>();
}
