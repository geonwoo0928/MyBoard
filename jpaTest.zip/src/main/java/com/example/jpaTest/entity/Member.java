package com.example.jpaTest.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@NamedQueries(
    {@NamedQuery(name = "Member.findByMemberName",
            query = "SELECT m FROM Member m WHERE m.name = :userName"),
    @NamedQuery(name = "Member.count" ,
            query = "SELECT COUNT(m) FROM Member m")}
            )
public class Member {
    @Id
    private String memberId;

    private String name;

    @ManyToOne(fetch = FetchType.LAZY) //EAGER=즉시로딩 , LAZY=지연로딩
    @JoinColumn(name = "teamId")
    private Team team;

    @Override
    public String toString() {
        return "Member{" +
                "memberId='" + memberId + '\'' +
                ", name='" + name + '\'' +
                ", team=" + team.getTeamName() +
                '}';
    }
}
