package com.example.jpaTest.service;

import com.example.jpaTest.entity.Member;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class ContextServiceTest {
    @Autowired
    ContextService contextService;

    @Test
    @DisplayName("1차 캐시 테스트")
    void memberInsert() {
        Member member = contextService.memberInsert();
        System.out.println(member);
    }

    @Test
    @DisplayName("트랜잭션 커밋 테스트")
    public void transactionTest(){
        contextService.transactionTest();
    }

    @Test
    @DisplayName("Dirty Checking Test")
    void dirtyCheckingTest(){
        contextService.dirtyChecking();
    }

    @Test
    @DisplayName("Delete Checking Test")
    void deleteCheckingTest(){
        contextService.deleteCheck();
    }
}