package com.example.jpaTest.service;

import com.example.jpaTest.entity.Member;
import com.example.jpaTest.entity.Parent;
import com.example.jpaTest.entity.Team;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class RelationTestServiceTest {
    @Autowired
    EntityManager em;

    @Autowired
    RelationTestService relationTestService;

    @Test
    @DisplayName("멤버와 팀 추가 테스트")
    void insertMemberAndTeam(){
        relationTestService.insertMemberAndTeam();
    }

    @Test
    @DisplayName("ID: 장원영의 팀 이름 찾기")
    void searchTeam(){
        Member member = em.find(Member.class , "장원영");
        Team team = em.find(Team.class , member.getTeam().getTeamId());

        System.out.println(team.getTeamName());
    }

//    @Test
//    @DisplayName("단방향 연관관계 - 데이터 입력")
//    void insertMemberAndTeamRelationTest(){
//        relationTestService.insertMemberAndTeamRelation();
//    }

    @Test
    void 단방향_설정_후_장원영_팀이름_찾기(){
        Member member = em.find(Member.class , "장원영");
        System.out.println(member.getTeam().getTeamName());
    }

    @Test
    void 양뱡향_연관관계_입력테스트(){
        relationTestService.insertBothDirectionRelation();
    }

    @Test
    void 양뱡향_설정_후_멤버의_팀이름_출력(){
        Member member = em.find(Member.class,"GeonWoo");
        System.out.println(member.getTeam().getTeamName());
    }

    @Test
    @Transactional
    void 양뱡향_설정_후_뉴진스_멤버_출력(){
        Team team = em.find(Team.class,"NewJeans");
        for(Member member : team.getMemberList()){
            System.out.println(member.toString());
        }
    }

    @Test
    void noCascade(){
        relationTestService.saveNoCascade();
    }

    @Test
    void saveCascade(){
        relationTestService.saveCascade();
    }

    @Test
    void deleteParent(){
        relationTestService.cascadeDelete();
    }

}