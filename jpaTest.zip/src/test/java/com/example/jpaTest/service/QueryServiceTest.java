package com.example.jpaTest.service;

import com.example.jpaTest.dto.MemberDto;
import com.example.jpaTest.entity.Member;
import com.example.jpaTest.entity.Team;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@Transactional
class QueryServiceTest {

    @Autowired
    QueryService queryService;

    @Test
    void dynamicQuery쿼리테스트_장원영찾기(){
        List<Member> list = queryService.dynamicQuery();
        for(Member member : list){
            System.out.println(member.getMemberId());
            System.out.println(member.getName());
            System.out.println(member.getTeam().getTeamName());
        }
    }

    @Test
    void dynamicQuery쿼리테스트_팀이름찾기(){
        List<Team> teamList = queryService.findAllTeam();
        for(Team team : teamList){
            System.out.println(team.getTeamId());
            System.out.println(team.getTeamName());
            for(Member member : team.getMemberList()){
                System.out.println(member.getName());
            }
        }
    }

    @Test
    void dynamicQuery쿼리테스트_멤버이름찾기(){
        List<String> nameList = queryService.findMemberName();
        for(String name : nameList){
            System.out.println(name);
        }
    }

    @Test
    void dynamicQuery쿼리테스트_뉴진스멤버찾기(){
        List<String> nameList = queryService.findNewJeansMemberName();
        for(String name : nameList){
            System.out.println(name);
        }
    }

    @Test
    void dynamicQuery쿼리테스트_뉴진스멤버수(){
        long memberCount = queryService.newJeansMemberCount();
        System.out.println(memberCount);
    }

    @Test
    void dynamicQuery쿼리테스트_멤버이름과팀이름dto(){
        List<MemberDto> memberDtos = queryService.findMemberNameAndTeamName();
        for(MemberDto member : memberDtos){
            System.out.println(member);
        }
    }

    @Test
    void dynamicQuery쿼리테스트_namedQuery테스트(){
        List<Member> memberList = queryService.findMemberNameNamedQuery();
        for (Member member : memberList){
            System.out.println(member);
        }
    }

    @Test
    void dynamicQuery쿼리테스트_nativeQuery테스트(){
        List<MemberDto> memberDtoList = queryService.findNativeQuery();
        for(MemberDto memberDto : memberDtoList){
            System.out.println(memberDto);
        }
    }
}