package com.myboard.repository;

import com.myboard.dto.Gender;
import com.myboard.entity.Member;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class MemberRepositoryTest {
    @Autowired
    MemberRepository memberRepository;

    void defaultDataInput(){
        Member m1 = Member.builder()
                .nickName("zzzmini")
                .email("test@mail.net")
                .gender(Gender.Male)
                .insertedAt(LocalDateTime.now().minusDays(2))
                .build();
        memberRepository.save(m1);

        Member jang = Member.builder()
                .nickName("원영이")
                .email("jang@mail.net")
                .gender(Gender.Female)
                .insertedAt(LocalDateTime.now().minusDays(1))
                .build();
        memberRepository.save(jang);
    }

    @Test
    @DisplayName("Member 테이블 입력")
    void inputUser() {
        Member member = new Member();
        member.setNickName("홍길동");
        member.setEmail("hong@naver.com");
        member.setGender(Gender.Male);
        member.setInsertedAt(LocalDateTime.now());
        member.setUpdatedAt(LocalDateTime.now());
        memberRepository.save(member);
    }

    @Test
    @DisplayName("user 테이블 수정")
    void updateUser() {
        defaultDataInput();
        Member userTest = new Member();
        Optional<Member> userTestOptionl = memberRepository.findById(1L);
        userTest = userTestOptionl.get();
        userTest.setNickName("형미니");
        userTest.setGender(Gender.Female);
        userTest.setInsertedAt(LocalDateTime.now().plusDays(2));
        userTest.setUpdatedAt(LocalDateTime.now().plusDays(2));
        memberRepository.save(userTest);
    }
}