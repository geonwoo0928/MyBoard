package com.myboard.constant;

public enum Gender {
    MALE,
    FEMALE
}
