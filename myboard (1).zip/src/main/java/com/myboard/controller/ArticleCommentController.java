package com.myboard.controller;

import com.myboard.dto.CommentDto;
import com.myboard.entity.Comment;
import com.myboard.repository.CommentRepository;
import com.myboard.service.ArticleService;
import com.myboard.service.CommentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Slf4j
public class ArticleCommentController {
    @Autowired
    CommentRepository commentRepository;
    @Autowired
    ArticleService articleService;

    @GetMapping("/articleComment/{id}/update")
    public String viewUpdateArticleComment(@PathVariable("id") Long id, Model model){
        Comment comment = commentRepository.findById(id).orElse(null);
        CommentDto commentDto = new CommentDto();
        if(comment != null){
            commentDto = CommentDto.entityToDto(comment);
        }
        model.addAttribute("dto" , commentDto);
        return "/articles/update-comment";
    }

    @GetMapping("/articles/{articleId}/articleComment/{id}")
    public String deleteComment(@PathVariable("id") Long id,
                                @PathVariable("articleId") Long articleId){
        commentRepository.deleteById(id);
        String url = "/articles/" + articleId;
        return "redirect:"+url;
    }

}
