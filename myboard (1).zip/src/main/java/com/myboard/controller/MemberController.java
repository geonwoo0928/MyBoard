package com.myboard.controller;

import com.myboard.entity.Member;
import com.myboard.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MemberController {
    @Autowired
    MemberRepository memberRepository;
    @GetMapping("/member")
    public String member(){
        Member member = new Member();
        member.setId(1L);
        member.setNickName("장원영");
        memberRepository.save(member);
        return "redirect:/articles";
    }
}
