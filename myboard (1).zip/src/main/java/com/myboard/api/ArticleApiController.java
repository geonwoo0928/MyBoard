package com.myboard.api;

import com.myboard.dto.ArticleForm;
import com.myboard.dto.ArticleForm_Old;
import com.myboard.entity.Article;
import com.myboard.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ArticleApiController {
    @Autowired
    ArticleService articleService;

    @GetMapping("/api/articles")
    public List<Article> listAll(){

        return articleService.showAllList();
    }

    @GetMapping("/api/articles/{id}")
    public Article listOne(@PathVariable("id") Long id){
        return articleService.showOneList(id);
    }

    @PostMapping("/api/articles")
    public Article createArticle(@RequestBody ArticleForm articleForm){
        return articleService.createArticle(articleForm);
    }

    @PatchMapping("/api/articles/{id}")
    public ResponseEntity<Article> updateArticle(@PathVariable("id") Long id , @RequestBody ArticleForm articleForm){
        return articleService.patchUpdate(id,articleForm);
    }

    @DeleteMapping("/api/articles/{id}")
    public ResponseEntity<Article> deleteArticle(@PathVariable("id") Long id){
        return articleService.delete(id);
    }
}
