package com.myboard.api;

import com.myboard.dto.CommentDto;
import com.myboard.entity.Comment;
import com.myboard.service.CommentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
public class CommentApiController {
    @Autowired
    CommentService commentService;
    //1. 댓글 조회

    //2. 댓글 생성
    @PostMapping("/api/articles/{articleId}/comments")
    public CommentDto create(@PathVariable("articleId") Long articleId ,
                             @RequestBody CommentDto dto){
        CommentDto createdDto = commentService.create(dto , articleId);
        return createdDto;
    }

    //3. 댓글 수정
    @PatchMapping("/api/comments/{id}")
    public CommentDto update(@PathVariable("id") Long id , @RequestBody CommentDto dto){
        CommentDto updateDto = commentService.update(id,dto);
        log.info(dto.toString());
        return updateDto;
    }

    //4. 댓글 삭제
    @DeleteMapping("/api/comments/{id}")
    public CommentDto delete(@PathVariable("id") Long id){
        CommentDto deletedDto = CommentDto.entityToDto(commentService.delete(id));
        return deletedDto;
    }
}
