package com.myboard.service;

import com.myboard.dto.CommentDto;
import com.myboard.entity.Article;
import com.myboard.entity.Comment;
import com.myboard.repository.ArticleRepository;
import com.myboard.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CommentService {

    @Autowired
    CommentRepository commentRepository;
    @Autowired
    ArticleRepository articleRepository;
    public List<CommentDto> comments(Long id) {
        List<Comment> commentList = commentRepository.findAllByArticleId(id);
        List<CommentDto> commentDtoList = new ArrayList<>();
        for(Comment comment : commentList){
            commentDtoList.add(CommentDto.entityToDto(comment));
            System.out.println(comment.toString());
        }
        return commentDtoList;
    } //article_id에 맞는 댓글들 가져오기

    public CommentDto update(Long id, CommentDto dto) {
        Comment target = commentRepository.findById(id).orElseThrow( ()-> new IllegalArgumentException("해당하는 댓글이 없습니다."));
        target.patch(dto);
        Comment updated = commentRepository.save(target);
        CommentDto commentDto = CommentDto.entityToDto(updated);
        return commentDto;
    }

    public Comment delete(Long id) {
        Comment target = commentRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("해당하는 댓글이 없습니다"));
        commentRepository.delete(target);
        return target;
    }

    public CommentDto create(CommentDto dto , Long id) {
        // 1.부모게시글 조회 없는 경우 오류 처리
        Article article = articleRepository.findById(id).orElseThrow( () -> new IllegalArgumentException("해당하는 게시글이 없습니다"));
        // 2. 댓글 엔티티 생성
        Comment comment = new Comment();
        comment.setArticle(article);
        comment.setNickname(dto.getNickname());
        comment.setBody(dto.getBody());
        // 3. 댓글 저장
        CommentDto commentDto = CommentDto.entityToDto(commentRepository.save(comment));
        // 4. 결과를 DTO로 리턴
        return commentDto;
    }
}
